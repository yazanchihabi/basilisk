#
# ISC License
#
# Copyright (c) 2026, Autonomous Vehicle Systems Lab, University of Colorado at Boulder
#
# Permission to use, copy, modify, and/or distribute this software for any
# purpose with or without fee is hereby granted, provided that the above
# copyright notice and this permission notice appear in all copies.
#
# THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
# WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
# ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
# WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
# ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
# OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
#

buildInfoData = {
    "schemaVersion": 4,
    "artifact": {
        "basiliskVersion": "2.13.0b0",
        "sourceRevision": "3193231686435252757a029ae74dba609b698ac1",
        "sourceDirty": False,
        "extensionAbiVersion": 3,
    },
    "features": {
        "vizInterface": True,
        "opNav": False,
        "mujoco": True,
        "rustModules": True,
    },
    "diagnostics": {
        "target": {
            "system": "Darwin",
            "processor": "arm64",
            "pointerSizeBytes": 8,
            "osxArchitectures": "arm64",
            "osxDeploymentTarget": "11.0",
        },
        "build": {
            "configuration": "Release",
            "multiConfig": False,
            "availableConfigurations": [],
            "generator": "Ninja",
            "generatorPlatform": "",
            "generatorToolset": "",
            "pythonLimitedApi": "0x03090000",
        },
        "compilers": {
            "c": {
                "id": "AppleClang",
                "version": "21.0.0.21000101",
                "executable": "cc",
                "launcher": "sccache",
                "frontendVariant": "GNU",
                "simulatedId": "",
                "simulatedVersion": "",
                "target": "",
                "standard": "",
                "extensions": "",
            },
            "cxx": {
                "id": "AppleClang",
                "version": "21.0.0.21000101",
                "executable": "c++",
                "launcher": "sccache",
                "frontendVariant": "GNU",
                "simulatedId": "",
                "simulatedVersion": "",
                "target": "",
                "standard": "17",
                "extensions": "OFF",
            },
            "rust": {
                "id": "rustc",
                "version": "1.99.1",
                "executable": "rustc",
                "launcher": "",
                "target": "aarch64-apple-darwin",
            },
        },
        "conanSettings": {
            "buildType": "Release",
            "cxxStandard": "17",
            "cxxStandardLibrary": "libc++",
            "compilerRuntime": "",
            "compilerRuntimeType": "",
        },
        "tools": {
            "cmake": "4.4.4",
            "conan": "2.33.0",
            "swig": "4.5.1",
            "python": "3.9.13",
            "cargo": "1.99.1",
            "corrosion": "0.6.1",
        },
    },
}
